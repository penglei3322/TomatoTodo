package com.example.dllo.tomatotodo.statistics;

import com.example.dllo.tomatotodo.base.BaseActivity;

/**
 * Created by dllo on 16/7/19.
 */
public class ObjectiveActivity extends BaseActivity{
    @Override
    public int initView() {
        return 0;
    }

    @Override
    public void initData() {

    }
}
