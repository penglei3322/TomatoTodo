package com.example.dllo.tomatotodo.potatolist.data;

/**
 * Created by dllo on 16/7/20.
 */
public class PhtatoListData  {
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
