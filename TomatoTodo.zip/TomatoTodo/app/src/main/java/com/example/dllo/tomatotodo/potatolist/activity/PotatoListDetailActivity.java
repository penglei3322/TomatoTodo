package com.example.dllo.tomatotodo.potatolist.activity;

import com.example.dllo.tomatotodo.R;
import com.example.dllo.tomatotodo.base.BaseActivity;

/**
 * Created by dllo on 16/7/19.
 */
public class PotatoListDetailActivity extends BaseActivity {
    @Override
    public int initView() {
        return R.layout.activity_potatolist_detail;
    }

    @Override
    public void initData() {

    }
}
