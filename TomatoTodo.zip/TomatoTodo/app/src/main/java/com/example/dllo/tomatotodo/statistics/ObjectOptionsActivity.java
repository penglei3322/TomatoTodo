package com.example.dllo.tomatotodo.statistics;

import com.example.dllo.tomatotodo.R;
import com.example.dllo.tomatotodo.base.BaseActivity;

/**
 * Created by dllo on 16/7/21.
 */
public class ObjectOptionsActivity extends BaseActivity {
    @Override
    public int initView() {
        return R.layout.activity_object_options;
    }

    @Override
    public void initData() {

    }
}
